## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----load package-------------------------------------------------------------
library(cleantimeuse)

## ----bypass ipums error-------------------------------------------------------
if (!require(remotes)) install.packages("remotes")
remotes::install_github("mnpopcenter/ipumsr")
library(ipumsr) #this overrides the ipumsr call built into the `cleantimeuse` package

## ----table of functions-------------------------------------------------------
table_of_functions <- read.csv("example_data/mtus_table_of_functions.csv")
knitr::kable(table_of_functions)

## -----------------------------------------------------------------------------
# setwd(getSrcDirectory()[1])

## ----load the data------------------------------------------------------------
by_person_data <- mtus_init_raw_data("example_data/mtus_00017.xml")

## ----load more----------------------------------------------------------------
by_person_data <- mtus_init_raw_data("example_data/mtus_00017.xml", 
                                     check = FALSE)
by_activity_data <- mtus_init_raw_data("example_data/mtus_00016.xml")

## ----mtus_init_countries------------------------------------------------------
mtus_init_countries(by_activity_data, 
                    by_person_data, 
                    "UK2014")

mtus_init_countries(by_activity_data, 
                    by_person_data, 
                    c("ZA2000","ZA2010"))

mtus_init_countries(by_activity_data, by_person_data, "all")

## ----display error if country is not available--------------------------------
mtus_init_countries(by_activity_data, by_person_data, "FR2008")

## ----init a_UK2014------------------------------------------------------------
mtus_init_countries(by_activity_data, NULL, "UK2014")

## ----init all by activity-----------------------------------------------------
mtus_init_countries(by_activity_data, NULL, "all")

## ----recode on the fly--------------------------------------------------------
mtus_init_countries(by_activity_data, NULL, "FR2009", 
                    recode_activities = TRUE, recode_locations = TRUE)

# or as a shortcut:
mtus_init_countries(by_activity_data, NULL, "FR2009", TRUE, TRUE)

## ----sample csv---------------------------------------------------------------
read.csv("example_data/codes_locations.csv")

## ----sample plots, echo=FALSE-------------------------------------------------
print("mtus_trip_density(FR2009")
mtus_trip_density(FR2009)

print("mtus_histogram(FR2009)")
mtus_histogram(FR2009)

print("mtus_density(FR2009)")
mtus_density(FR2009)

print("mtus_scatter(FR2009)")
mtus_scatter(FR2009)

#From the original R Markdown template:"Note that the `echo = FALSE` parameter was added to the code chunk to prevent printing of the R code that generated the plot."

## ----French/Dutch overlay, echo=FALSE-----------------------------------------
mtus_init_countries(by_activity_data, 
                    by_person_data, 
                    "NL2005")
mtus_density_ov(FR2009, NL2005)

## ----multiple countries-------------------------------------------------------
my_countries <- c("ES2009", "FI2009", "HU2009", "KR2009")
mtus_init_countries(by_activity_data,
                    by_person_data,
                    my_countries)

## ----more overlays------------------------------------------------------------
mtus_density_ov(ES2009, FI2009)
mtus_density_ov(HU2009, KR2009)

